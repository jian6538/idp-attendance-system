"""
download_weights.py
===================
One-time helper: downloads the MiniFASNetV2 ONNX weights from the
yakhyo/face-anti-spoofing GitHub release and saves them to:

    anti_spoof_weights/MiniFASNetV2.onnx

Run once before starting the system:
    python download_weights.py
"""

from __future__ import annotations

import os
import sys
import urllib.request

SAVE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "anti_spoof_weights")
SAVE_PATH = os.path.join(SAVE_DIR, "MiniFASNetV2.onnx")

WEIGHT_URL = (
    "https://github.com/yakhyo/face-anti-spoofing/releases/download/weights/MiniFASNetV2.onnx"
)

EXPECTED_MIN_MB = 0.5   # sanity check — file should be at least 500 KB


def _progress(count: int, block_size: int, total_size: int) -> None:
    pct = int(count * block_size * 100 / max(total_size, 1))
    pct = min(pct, 100)
    bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
    sys.stdout.write(f"\r  [{bar}] {pct}%")
    sys.stdout.flush()


def download() -> bool:
    os.makedirs(SAVE_DIR, exist_ok=True)

    if os.path.isfile(SAVE_PATH):
        size_mb = os.path.getsize(SAVE_PATH) / 1_048_576
        print(f"Already downloaded ({size_mb:.1f} MB): {SAVE_PATH}")
        return True

    print("Downloading MiniFASNetV2.onnx from GitHub...")
    print(f"  Source : {WEIGHT_URL}")
    print(f"  Dest   : {SAVE_PATH}")

    try:
        urllib.request.urlretrieve(WEIGHT_URL, SAVE_PATH, _progress)
        print()  # newline after progress bar
    except Exception as e:
        print(f"\nERROR: download failed — {e}")
        if os.path.isfile(SAVE_PATH):
            os.remove(SAVE_PATH)
        print("\nManual download steps:")
        print("  1. Open this URL in your browser:")
        print(f"     {WEIGHT_URL}")
        print(f"  2. Save the file to:  {SAVE_PATH}")
        return False

    size_mb = os.path.getsize(SAVE_PATH) / 1_048_576
    print(f"✓ Saved ({size_mb:.1f} MB): {SAVE_PATH}")

    if size_mb < EXPECTED_MIN_MB:
        print(
            "WARNING: file seems too small — it may be corrupted.\n"
            "Delete it and re-run this script, or download manually."
        )
        return False

    return True


if __name__ == "__main__":
    ok = download()
    sys.exit(0 if ok else 1)
