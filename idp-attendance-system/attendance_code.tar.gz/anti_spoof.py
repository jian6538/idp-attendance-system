"""
anti_spoof.py
=============
Silent Face Anti-Spoofing via ONNX Runtime.

Uses the MiniFASNetV2.onnx model from yakhyo/face-anti-spoofing — an ONNX
export of MiniVision's lightweight liveness detector.

Using ONNX avoids any PyTorch architecture mismatch: the model is
self-contained inside the .onnx file.

Model:  MiniFASNetV2  (~0.43 M params)
Input:  (1, 3, 80, 80)  float32  normalised to [0, 1]
Output: logits (1, N)  where index-1 = Real probability  (index-0 = Fake)
Crop scale: 2.7× the MTCNN bounding box

Public API:
    load_anti_spoof_model(weights_path)       → ort.InferenceSession or None
    is_live_face(frame_bgr, box, session, threshold)  → bool
"""

from __future__ import annotations

import os
from typing import List, Optional

import cv2
import numpy as np

# onnxruntime is CPU-only and lightweight (~7 MB).
# It is imported lazily so the rest of the system still imports
# even if the package is not yet installed.
try:
    import onnxruntime as ort
    _ORT_AVAILABLE = True
except ImportError:
    _ORT_AVAILABLE = False

WEIGHTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "anti_spoof_weights")
DEFAULT_WEIGHTS = os.path.join(WEIGHTS_DIR, "MiniFASNetV2.onnx")

CROP_SCALE = 2.7          # recommended scale for MiniFASNetV2
INPUT_SIZE = (80, 80)     # fixed model input (W, H) for cv2.resize
DEFAULT_LIVENESS_THRESHOLD = 0.01   # real-face probability must exceed this
                                    # lower = more permissive, higher = stricter


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def load_anti_spoof_model(weights_path: str = DEFAULT_WEIGHTS):
    """Load MiniFASNetV2.onnx and return an ONNX Runtime InferenceSession.

    Returns None (with a printed warning) if:
    - onnxruntime is not installed
    - the weights file is missing

    The main loop falls back to no liveness check rather than crashing.
    """
    if not _ORT_AVAILABLE:
        print(
            "[AntiSpoof] WARNING: 'onnxruntime' is not installed.\n"
            "  Run:  pip install onnxruntime\n"
            "  Liveness check will be DISABLED."
        )
        return None

    if not os.path.isfile(weights_path):
        print(
            f"[AntiSpoof] WARNING: weights not found at {weights_path}\n"
            "  Run  python download_weights.py  to fetch them.\n"
            "  Liveness check will be DISABLED until weights are available."
        )
        return None

    try:
        sess_options = ort.SessionOptions()
        sess_options.inter_op_num_threads = 2
        sess_options.intra_op_num_threads = 2
        session = ort.InferenceSession(
            weights_path,
            sess_options=sess_options,
            providers=["CPUExecutionProvider"],
        )
        # Quick smoke-test with a dummy input to catch shape mismatches early.
        dummy = np.zeros((1, 3, 80, 80), dtype=np.float32)
        input_name = session.get_inputs()[0].name
        session.run(None, {input_name: dummy})
        return session
    except Exception as e:
        print(f"[AntiSpoof] WARNING: failed to load ONNX model ({e}). Liveness DISABLED.")
        return None


def _softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)


def _crop_for_antispoof(
    frame_bgr: np.ndarray,
    box: List[int],
    scale: float = CROP_SCALE,
    size: tuple = INPUT_SIZE,
) -> Optional[np.ndarray]:
    """Return (1, 3, 80, 80) float32 numpy array ready for ONNX inference."""
    h, w = frame_bgr.shape[:2]
    x1, y1, x2, y2 = [int(v) for v in box]

    cx = (x1 + x2) / 2.0
    cy = (y1 + y2) / 2.0
    bw = (x2 - x1) * scale
    bh = (y2 - y1) * scale

    nx1 = max(0, int(cx - bw / 2))
    ny1 = max(0, int(cy - bh / 2))
    nx2 = min(w, int(cx + bw / 2))
    ny2 = min(h, int(cy + bh / 2))

    if nx2 <= nx1 or ny2 <= ny1:
        return None

    crop = frame_bgr[ny1:ny2, nx1:nx2]
    if crop.size == 0:
        return None

    crop_rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
    crop_resized = cv2.resize(crop_rgb, size)           # (80, 80, 3)  uint8

    # HWC uint8 → CHW float32 [0, 1], add batch dim
    tensor = (
        crop_resized.astype(np.float32) / 255.0        # (80, 80, 3)
    ).transpose(2, 0, 1)[np.newaxis, ...]              # (1, 3, 80, 80)
    return np.ascontiguousarray(tensor)


def is_live_face(
    frame_bgr: np.ndarray,
    box: List[int],
    session,                          # ort.InferenceSession or None
    threshold: float = DEFAULT_LIVENESS_THRESHOLD,
) -> tuple:
    """Return (is_live: bool, real_prob: float).

    is_live  — True if real person, False if spoof
    real_prob — raw score (0.0–1.0) useful for threshold tuning on screen

    Falls back to (True, 1.0) if session is None.
    """
    if session is None:
        return True, 1.0  # liveness disabled — pass through

    tensor = _crop_for_antispoof(frame_bgr, box)
    if tensor is None:
        return True, 1.0  # crop failed — don't block

    try:
        input_name = session.get_inputs()[0].name
        logits = session.run(None, {input_name: tensor})[0]  # (1, N)

        probs = _softmax(logits)[0]   # (N,)

        # 3-class model: [fake-print, fake-replay, real]  → index 2 = Real
        # 2-class model: [fake, real]                     → index 1 = Real
        if len(probs) >= 3:
            real_prob = float(probs[2])
        elif len(probs) == 2:
            real_prob = float(probs[1])
        else:
            real_prob = float(probs[0])

        return real_prob >= threshold, real_prob
    except Exception:
        return True, 1.0  # fail open on any inference error
